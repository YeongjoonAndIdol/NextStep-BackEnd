package com.prject.nextstep.domain.quest.dto

enum class Type {
    ALL, NOT_COMPLETE, COMPLETE
}