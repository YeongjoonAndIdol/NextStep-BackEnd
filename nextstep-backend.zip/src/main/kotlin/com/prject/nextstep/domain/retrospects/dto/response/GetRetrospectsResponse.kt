package com.prject.nextstep.domain.retrospects.dto.response

data class GetRetrospectsResponse(
    val content: String
)