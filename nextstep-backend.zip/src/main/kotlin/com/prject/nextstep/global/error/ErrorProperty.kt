package com.prject.nextstep.global.error

interface ErrorProperty {

    fun status(): Int

    fun message(): String
}