package com.prject.nextstep

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class NextstepApplication

fun main(args: Array<String>) {
    runApplication<NextstepApplication>(*args)
}
