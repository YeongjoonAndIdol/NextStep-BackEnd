package com.prject.nextstep

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class NextstepApplicationTests {

    @Test
    fun contextLoads() {
    }

}
